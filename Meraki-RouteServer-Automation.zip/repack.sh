#!/bin/bash

rm *.zip
zip -r Meraki-RouteServer-Automation.zip . -x 'venv/*' -x '.idea/*' -x '.git/*' -x 'requirements.txt'
zip -r Meraki-RouteServer-Automation.zip . -x 'venv/*' -x '.idea/*' -x '.git/*' -x 'requirements.txt'
zip -r Meraki-RouteServer-Automation.zip . -x 'venv/*' -x '.idea/*' -x '.git/*' -x '.python_packages/*'
git add Meraki-RouteServer-Automation.zip

